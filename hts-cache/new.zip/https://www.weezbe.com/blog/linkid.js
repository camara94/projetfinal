<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" lang="fr-FR" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if IE 7]>
<html id="ie7" lang="fr-FR" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if IE 8]>
<html id="ie8" lang="fr-FR" prefix="og: http://ogp.me/ns#">
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html lang="fr-FR" prefix="og: http://ogp.me/ns#">
<!--<![endif]-->
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="google-site-verification" content="LTG-y2N8JeY7OaxDRpdRXZU3gZrOnr1sz_CUMKhWtE0" />
		<meta name="msvalidate.01" content="02191E97DAB79EA0C1DD709C865F0C62" />
		<title>Page non trouvée | weezbe</title>
		<link rel="profile" href="http://gmpg.org/xfn/11" />
				<link rel="pingback" href="https://www.weezbe.com/xmlrpc.php" />
		<!--[if lt IE 9]>
		<script src="https://www.weezbe.com/wp-content/themes/weezbe/js/html5.js" type="text/javascript"></script>
		<![endif]-->
		
<!-- This site is optimized with the Yoast SEO plugin v7.9.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="fr_FR" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page non trouvée | weezbe" />
<meta property="og:site_name" content="weezbe" />
<meta property="fb:app_id" content="187266298150491" />
<meta property="og:image" content="https://www.weezbe.com/wp-content/themes/weezbe/images/solution-ecommerce-gratuite.png" />
<meta property="og:image:secure_url" content="https://www.weezbe.com/wp-content/themes/weezbe/images/solution-ecommerce-gratuite.png" />
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//medias.weezbe.com' />
<link rel='dns-prefetch' href='//maxcdn.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="weezbe &raquo; Flux" href="https://www.weezbe.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="weezbe &raquo; Flux des commentaires" href="https://www.weezbe.com/comments/feed/" />
<!-- This site uses the Google Analytics by MonsterInsights plugin v7.2.0 - Using Analytics tracking - https://www.monsterinsights.com/ -->
<script type="text/javascript" data-cfasync="false">
	var mi_version         = '7.2.0';
	var mi_track_user      = true;
	var mi_no_track_reason = '';
	
	var disableStr = 'ga-disable-UA-8127107-1';

	/* Function to detect opted out users */
	function __gaTrackerIsOptedOut() {
		return document.cookie.indexOf(disableStr + '=true') > -1;
	}

	/* Disable tracking if the opt-out cookie exists. */
	if ( __gaTrackerIsOptedOut() ) {
		window[disableStr] = true;
	}

	/* Opt-out function */
	function __gaTrackerOptout() {
	  document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
	  window[disableStr] = true;
	}
	
	if ( mi_track_user ) {
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','__gaTracker');

		__gaTracker('create', 'UA-8127107-1', 'auto');
		__gaTracker('set', 'forceSSL', true);
		__gaTracker('require', 'displayfeatures');
		__gaTracker('require', 'linkid', 'linkid.js');
		__gaTracker('send','pageview','/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer);
	} else {
		console.log( "" );
		(function() {
			/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
			var noopfn = function() {
				return null;
			};
			var noopnullfn = function() {
				return null;
			};
			var Tracker = function() {
				return null;
			};
			var p = Tracker.prototype;
			p.get = noopfn;
			p.set = noopfn;
			p.send = noopfn;
			var __gaTracker = function() {
				var len = arguments.length;
				if ( len === 0 ) {
					return;
				}
				var f = arguments[len-1];
				if ( typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function' ) {
					console.log( 'Not running function __gaTracker(' + arguments[0] + " ....) because you are not being tracked. " + mi_no_track_reason );
					return;
				}
				try {
					f.hitCallback();
				} catch (ex) {

				}
			};
			__gaTracker.create = function() {
				return new Tracker();
			};
			__gaTracker.getByName = noopnullfn;
			__gaTracker.getAll = function() {
				return [];
			};
			__gaTracker.remove = noopfn;
			window['__gaTracker'] = __gaTracker;
					})();
		}
</script>
<!-- / Google Analytics by MonsterInsights -->
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.weezbe.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.8"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-group-css' href='https://www.weezbe.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/contact-form-7/includes/css/styles.css,wp-content/themes/weezbe/style.css,wp-content/plugins/jetpack/modules/subscriptions/subscriptions.css,wp-content/plugins/jetpack/modules/widgets/social-icons/social-icons.css,wp-content/plugins/jetpack/css/jetpack.css' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://www.weezbe.com/wp-includes/css/dashicons.min.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-ui-custom-css'  href='https://medias.weezbe.com/assets/styles/jquery-ui-.custom.css?ver=2016-06-30' type='text/css' media='all' />
<link rel='stylesheet' id='google-fonts-css'  href='https://fonts.googleapis.com/css?family=Open+Sans%3A400%2C600%2C700%7CCatamaran%3A400%2C600&#038;ver=4.9.8' type='text/css' media='all' />
<script type='text/javascript' src='https://www.weezbe.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://www.weezbe.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://medias.weezbe.com/assets/cache/jquery.cookie-min.js?ver=4.9.8'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var monsterinsights_frontend = {"js_events_tracking":"true","is_debug_mode":"false","download_extensions":"doc,exe,js,pdf,ppt,tgz,zip,xls","inbound_paths":"","home_url":"https:\/\/www.weezbe.com","track_download_as":"event","internal_label":"int","hash_tracking":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.weezbe.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend.min.js,include/general.js'></script>
<link rel='https://api.w.org/' href='https://www.weezbe.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.weezbe.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.weezbe.com/wp-includes/wlwmanifest.xml" /> 

<link rel='dns-prefetch' href='//v0.wordpress.com'/>
<style type='text/css'>img#wpstats{display:none}</style>		<script type="text/javascript">
			<!--
				jQuery.noConflict();
				var site_url = 'https://www.weezbe.com/';
			//-->
			var nb_store_created = '37011';
		</script>
					<link rel="image_src" href="https://www.weezbe.com/wp-content/themes/default/images/fb_publication.png" />
				<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
		<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css" type="text/css" />
		<link rel="shortcut icon" href="https://www.weezbe.com/wp-content/themes/weezbe/images/favicon.png" />
											</head>
	<body class="error404 single-author two-column right-sidebar">
		<div id="fb-root"></div>
		<script>
		  window.fbAsyncInit = function() {
		    FB.init({
		      xfbml      : true,
		      version    : 'v2.4'
		    });
		  };

		  (function(d, s, id){
		     var js, fjs = d.getElementsByTagName(s)[0];
		     if (d.getElementById(id)) {return;}
		     js = d.createElement(s); js.id = id;
		     js.src = "//connect.facebook.net/fr_FR/sdk.js";
		     fjs.parentNode.insertBefore(js, fjs);
		   }(document, 'script', 'facebook-jssdk'));
		</script>
		<div id="bgrd">
		<div id="page" class="hfeed">
			<header id="branding" role="banner">
				<div class="container">
					<div id="site-title">
						<a href="https://www.weezbe.com/" title="weezbe" rel="home"><img src="https://www.weezbe.com/wp-content/themes/weezbe/images/solution-ecommerce-gratuite.png" alt="creer site e-commerce" height="41" width="180" /></a>
					</div>
					<!--<h2 id="site-description"></h2>-->

					
												<form method="get" id="searchform" action="https://www.weezbe.com/">
		<label for="s" class="assistive-text">Recherche</label>
		<input type="text" class="field" name="s" id="s" placeholder="Recherche" />
		<input type="submit" class="submit" name="submit" id="searchsubmit" value="Recherche" />
	</form>
										<div id="login-register">
													<a class="link" title="Connexion" href="https://admin.weezbe.com/">Connexion</a>
							<a class="btn btn-register" title="Créer ma boutique" href="#footer-infos">Créer ma boutique</a>
											</div>
					<nav id="access" role="navigation">
						<h3 class="assistive-text">Menu principal</h3>
												<div class="skip-link"><a class="assistive-text" href="#content" title="Aller au contenu principal">Aller au contenu principal</a></div>
						<div class="skip-link"><a class="assistive-text" href="#secondary" title="Aller au contenu secondaire">Aller au contenu secondaire</a></div>
												<a href="#" class="navbar-toggle">Menu<span class="icon"></span></a>
						<div class="menu-menu-header-container"><ul id="menu-menu-header" class="menu"><li id="menu-item-4977" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4977"><a href="https://www.weezbe.com/fonctionnalites/">Fonctionnalités</a></li>
<li id="menu-item-2767" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2767"><a href="https://www.weezbe.com/prix-tarifs-creer-site-ecommerce/">Tarifs</a></li>
<li id="menu-item-2762" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-2762"><a href="https://www.weezbe.com/agence-web-e-commerce/">Services E-commerce</a>
<ul class="sub-menu">
	<li id="menu-item-4364" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4364"><a href="https://www.weezbe.com/agence-web-e-commerce/charte-graphique/">Design sur mesure</a></li>
	<li id="menu-item-5273" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5273"><a href="https://www.weezbe.com/agence-web-e-commerce/accompagnement-optimisation-ecommerce/">Offres d’Accompagnement &#038; d’Optimisation</a></li>
	<li id="menu-item-4365" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4365"><a href="https://www.weezbe.com/agence-web-e-commerce/referencement/">Référencement</a></li>
	<li id="menu-item-4363" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4363"><a href="https://www.weezbe.com/agence-web-e-commerce/packs-projets-ecommerce/">Packs e-commerce</a></li>
</ul>
</li>
<li id="menu-item-2768" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-2768"><a href="https://www.weezbe.com/blog/">Blog</a></li>
</ul></div>					</nav><!-- #access -->

														</div>
			</header><!-- #branding -->
			<div id="main">
	<div id="primary">
		<div id="content" role="main">

			<article id="post-0" class="post error404 not-found">
				<header class="entry-header">
					<h1 class="entry-title">C&rsquo;est plutôt gênant, vous ne trouvez pas&nbsp;?</h1>
				</header>

				<div class="entry-content">
					<p>Il semblerait que nous ne soyons pas en mesure de trouver votre contenu. Essayez en lançant une recherche, ou à l&rsquo;aide de l&rsquo;un des lien ci-dessous.</p>

						<form method="get" id="searchform" action="https://www.weezbe.com/">
		<label for="s" class="assistive-text">Recherche</label>
		<input type="text" class="field" name="s" id="s" placeholder="Recherche" />
		<input type="submit" class="submit" name="submit" id="searchsubmit" value="Recherche" />
	</form>

							<div class="widget widget_recent_entries">		<h2 class="widgettitle">Articles récents</h2>		<ul>
											<li>
					<a href="https://www.weezbe.com/blog/stripe-comment-lintegrer-a-votre-boutique-weezbe/">Stripe : comment l&rsquo;intégrer à votre boutique weezbe</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/nouveau-theme-weezbe/">Découvrez les thèmes graphiques pour weezbe</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/reference-les-petites-chouettes/">Les Petites Chouettes, mais qui sont-elles ?</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/paiement-payzen/">Nouvelle solution de paiement : PayZen</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/workwear-pro/">WORKWEAR-PRO : Le vestiaire du professionnel</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/worldline-sips/">Nouveau mode de paiement : Worldline Sips</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/ledenicheur/">Diffusez vos produits sur leDénicheur !</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/chronopost-annonce-livraison-le-dimanche/">Chronopost annonce la livraison le dimanche</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/nord-riding-have-fun-enjoy-to-ride/">Nord Riding : Have Fun &#038; Enjoy to Ride !</a>
									</li>
											<li>
					<a href="https://www.weezbe.com/blog/donnees-structurees-referencement-seo/">Amélioration du référencement de votre boutique grâce aux données structurées (Google)</a>
									</li>
					</ul>
		</div>
					<div class="widget">
						<h2 class="widgettitle">Catégories les plus utilisées</h2>
						<ul>
							<li class="cat-item cat-item-4"><a href="https://www.weezbe.com/blog/category/actualites-site-e-commerce/" title="Suivez l&#039;actualité du e-commerce avec weezbe">E-commerce</a> (46)
</li>
	<li class="cat-item cat-item-5"><a href="https://www.weezbe.com/blog/category/actualite-solution-e-commerce-weezbe/" title="Toute l&#039;actualité de la plateforme de création de sites e-commerce à la performance weezbe : les mises à jours, les nouveautés, les événements...">Actualité weezbe</a> (41)
</li>
	<li class="cat-item cat-item-8"><a href="https://www.weezbe.com/blog/category/eboulette-de-romuald/" title="Retrouvez toutes les e-boulettes de  Romuald et les conseils e-commerce associés">E-boulette de Romuald</a> (25)
</li>
	<li class="cat-item cat-item-10"><a href="https://www.weezbe.com/blog/category/referencement-naturel-site-e-commerce/" title="Tous les conseils sur le référencement d&#039;une boutique e-commerce sur le blog de weezbe, solution e-commerce.">Référencement Naturel</a> (12)
</li>
	<li class="cat-item cat-item-12"><a href="https://www.weezbe.com/blog/category/tutoriel-weezbe/" title="Cette catégorie recense tous les tutoriels officiels relatifs à la solution weezbe. Suivez pas-à-pas nos conseils d&#039;optimisation de votre boutique !">Tutoriels weezbe</a> (12)
</li>
	<li class="cat-item cat-item-78"><a href="https://www.weezbe.com/blog/category/exemples-boutiques-weezbe-references/" title="Dans cette rubrique nous mettons à l&#039;honneur les boutiques weezbe de nos clients.">Parlons de nos clients</a> (12)
</li>
	<li class="cat-item cat-item-79"><a href="https://www.weezbe.com/blog/category/ergonomie/" title="Tous les conseils en ergonomie de l&#039;équipe weezbe">Ergonomie</a> (8)
</li>
	<li class="cat-item cat-item-7"><a href="https://www.weezbe.com/blog/category/comparateurs-marketplaces/" title="Tous les articles concernant les comparateurs de prix sur le blog de weezbe : création de boutique en ligne multicanal.">Comparateurs / Marketplaces</a> (6)
</li>
	<li class="cat-item cat-item-81"><a href="https://www.weezbe.com/blog/category/e-mailing/" title="Tous les conseils pour gérer au mieux vos campagnes e-mailing.">E-mailing</a> (6)
</li>
	<li class="cat-item cat-item-175"><a href="https://www.weezbe.com/blog/category/conseils-optimisations-ecommerce/" title="Retrouvez tous nos conseils et nos propositions d&#039;optimisations web-marketing et e-merchandising pour votre boutique en ligne autour des grands thèmes de l&#039;e-commerce .">Conseils et Optimisations</a> (5)
</li>
						</ul>
					</div>

					<div class="widget widget_archive"><h2 class="widgettitle">Archives</h2><p>Essayez de voir du côté des archives mensuelles. 🙂</p>		<label class="screen-reader-text" for="archives-dropdown--1">Archives</label>
		<select id="archives-dropdown--1" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
			
			<option value="">Sélectionner un mois</option>
				<option value='https://www.weezbe.com/blog/2018/09/'> septembre 2018 </option>
	<option value='https://www.weezbe.com/blog/2018/06/'> juin 2018 </option>
	<option value='https://www.weezbe.com/blog/2018/05/'> mai 2018 </option>
	<option value='https://www.weezbe.com/blog/2018/04/'> avril 2018 </option>
	<option value='https://www.weezbe.com/blog/2018/02/'> février 2018 </option>
	<option value='https://www.weezbe.com/blog/2017/11/'> novembre 2017 </option>
	<option value='https://www.weezbe.com/blog/2017/09/'> septembre 2017 </option>
	<option value='https://www.weezbe.com/blog/2017/06/'> juin 2017 </option>
	<option value='https://www.weezbe.com/blog/2017/05/'> mai 2017 </option>
	<option value='https://www.weezbe.com/blog/2017/01/'> janvier 2017 </option>
	<option value='https://www.weezbe.com/blog/2016/11/'> novembre 2016 </option>
	<option value='https://www.weezbe.com/blog/2016/06/'> juin 2016 </option>
	<option value='https://www.weezbe.com/blog/2016/04/'> avril 2016 </option>
	<option value='https://www.weezbe.com/blog/2016/02/'> février 2016 </option>
	<option value='https://www.weezbe.com/blog/2015/12/'> décembre 2015 </option>
	<option value='https://www.weezbe.com/blog/2015/10/'> octobre 2015 </option>
	<option value='https://www.weezbe.com/blog/2015/08/'> août 2015 </option>
	<option value='https://www.weezbe.com/blog/2015/07/'> juillet 2015 </option>
	<option value='https://www.weezbe.com/blog/2015/05/'> mai 2015 </option>
	<option value='https://www.weezbe.com/blog/2015/03/'> mars 2015 </option>
	<option value='https://www.weezbe.com/blog/2014/12/'> décembre 2014 </option>
	<option value='https://www.weezbe.com/blog/2014/09/'> septembre 2014 </option>
	<option value='https://www.weezbe.com/blog/2014/05/'> mai 2014 </option>
	<option value='https://www.weezbe.com/blog/2014/02/'> février 2014 </option>
	<option value='https://www.weezbe.com/blog/2014/01/'> janvier 2014 </option>
	<option value='https://www.weezbe.com/blog/2013/12/'> décembre 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/11/'> novembre 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/10/'> octobre 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/09/'> septembre 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/08/'> août 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/07/'> juillet 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/06/'> juin 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/05/'> mai 2013 </option>
	<option value='https://www.weezbe.com/blog/2013/03/'> mars 2013 </option>
	<option value='https://www.weezbe.com/blog/2012/08/'> août 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/07/'> juillet 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/06/'> juin 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/05/'> mai 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/04/'> avril 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/03/'> mars 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/02/'> février 2012 </option>
	<option value='https://www.weezbe.com/blog/2012/01/'> janvier 2012 </option>
	<option value='https://www.weezbe.com/blog/2011/10/'> octobre 2011 </option>
	<option value='https://www.weezbe.com/blog/2011/09/'> septembre 2011 </option>
	<option value='https://www.weezbe.com/blog/2011/07/'> juillet 2011 </option>
	<option value='https://www.weezbe.com/blog/2011/06/'> juin 2011 </option>
	<option value='https://www.weezbe.com/blog/2011/05/'> mai 2011 </option>
	<option value='https://www.weezbe.com/blog/2010/12/'> décembre 2010 </option>
	<option value='https://www.weezbe.com/blog/2010/09/'> septembre 2010 </option>
	<option value='https://www.weezbe.com/blog/2010/02/'> février 2010 </option>
	<option value='https://www.weezbe.com/blog/2010/01/'> janvier 2010 </option>
	<option value='https://www.weezbe.com/blog/2009/12/'> décembre 2009 </option>
	<option value='https://www.weezbe.com/blog/2009/11/'> novembre 2009 </option>
	<option value='https://www.weezbe.com/blog/2009/10/'> octobre 2009 </option>
	<option value='https://www.weezbe.com/blog/2009/09/'> septembre 2009 </option>

		</select>
		</div>
					<div class="widget widget_tag_cloud"><h2 class="widgettitle">Étiquettes</h2><div class="tagcloud"><a href="https://www.weezbe.com/blog/tag/actualite-solution-e-commerce-weezbe/" class="tag-cloud-link tag-link-166 tag-link-position-1" style="font-size: 15pt;" aria-label="Actualité weezbe (5 éléments)">Actualité weezbe</a>
<a href="https://www.weezbe.com/blog/tag/ameliorer/" class="tag-cloud-link tag-link-113 tag-link-position-2" style="font-size: 8pt;" aria-label="améliorer (2 éléments)">améliorer</a>
<a href="https://www.weezbe.com/blog/tag/analyse/" class="tag-cloud-link tag-link-142 tag-link-position-3" style="font-size: 10.8pt;" aria-label="analyse (3 éléments)">analyse</a>
<a href="https://www.weezbe.com/blog/tag/blog/" class="tag-cloud-link tag-link-126 tag-link-position-4" style="font-size: 8pt;" aria-label="blog (2 éléments)">blog</a>
<a href="https://www.weezbe.com/blog/tag/boulette-ecommerce/" class="tag-cloud-link tag-link-84 tag-link-position-5" style="font-size: 8pt;" aria-label="boulette ecommerce (2 éléments)">boulette ecommerce</a>
<a href="https://www.weezbe.com/blog/tag/boutique-en-ligne/" class="tag-cloud-link tag-link-19 tag-link-position-6" style="font-size: 15pt;" aria-label="boutique en ligne (5 éléments)">boutique en ligne</a>
<a href="https://www.weezbe.com/blog/tag/checkout/" class="tag-cloud-link tag-link-112 tag-link-position-7" style="font-size: 13.133333333333pt;" aria-label="checkout (4 éléments)">checkout</a>
<a href="https://www.weezbe.com/blog/tag/chiffres-cles/" class="tag-cloud-link tag-link-23 tag-link-position-8" style="font-size: 8pt;" aria-label="chiffres clés (2 éléments)">chiffres clés</a>
<a href="https://www.weezbe.com/blog/tag/click-to-chat/" class="tag-cloud-link tag-link-140 tag-link-position-9" style="font-size: 8pt;" aria-label="click to chat (2 éléments)">click to chat</a>
<a href="https://www.weezbe.com/blog/tag/comparateurs-marketplaces/" class="tag-cloud-link tag-link-167 tag-link-position-10" style="font-size: 13.133333333333pt;" aria-label="Comparateurs / Marketplaces (4 éléments)">Comparateurs / Marketplaces</a>
<a href="https://www.weezbe.com/blog/tag/conseil/" class="tag-cloud-link tag-link-97 tag-link-position-11" style="font-size: 8pt;" aria-label="conseil (2 éléments)">conseil</a>
<a href="https://www.weezbe.com/blog/tag/conversion/" class="tag-cloud-link tag-link-111 tag-link-position-12" style="font-size: 10.8pt;" aria-label="conversion (3 éléments)">conversion</a>
<a href="https://www.weezbe.com/blog/tag/creer-un-site-e-commerce/" class="tag-cloud-link tag-link-31 tag-link-position-13" style="font-size: 8pt;" aria-label="créer un site e-commerce (2 éléments)">créer un site e-commerce</a>
<a href="https://www.weezbe.com/blog/tag/e-commerce/" class="tag-cloud-link tag-link-34 tag-link-position-14" style="font-size: 22pt;" aria-label="e-commerce (11 éléments)">e-commerce</a>
<a href="https://www.weezbe.com/blog/tag/e-merchandising/" class="tag-cloud-link tag-link-168 tag-link-position-15" style="font-size: 10.8pt;" aria-label="E-merchandising (3 éléments)">E-merchandising</a>
<a href="https://www.weezbe.com/blog/tag/eboulette/" class="tag-cloud-link tag-link-82 tag-link-position-16" style="font-size: 13.133333333333pt;" aria-label="eboulette (4 éléments)">eboulette</a>
<a href="https://www.weezbe.com/blog/tag/exemple-boutique/" class="tag-cloud-link tag-link-39 tag-link-position-17" style="font-size: 8pt;" aria-label="exemple boutique (2 éléments)">exemple boutique</a>
<a href="https://www.weezbe.com/blog/tag/extensions/" class="tag-cloud-link tag-link-90 tag-link-position-18" style="font-size: 13.133333333333pt;" aria-label="extensions (4 éléments)">extensions</a>
<a href="https://www.weezbe.com/blog/tag/facebook/" class="tag-cloud-link tag-link-123 tag-link-position-19" style="font-size: 8pt;" aria-label="facebook (2 éléments)">facebook</a>
<a href="https://www.weezbe.com/blog/tag/google/" class="tag-cloud-link tag-link-49 tag-link-position-20" style="font-size: 13.133333333333pt;" aria-label="google (4 éléments)">google</a>
<a href="https://www.weezbe.com/blog/tag/graphisme/" class="tag-cloud-link tag-link-93 tag-link-position-21" style="font-size: 8pt;" aria-label="graphisme (2 éléments)">graphisme</a>
<a href="https://www.weezbe.com/blog/tag/kelkoo/" class="tag-cloud-link tag-link-51 tag-link-position-22" style="font-size: 10.8pt;" aria-label="kelkoo (3 éléments)">kelkoo</a>
<a href="https://www.weezbe.com/blog/tag/leguide-com/" class="tag-cloud-link tag-link-52 tag-link-position-23" style="font-size: 10.8pt;" aria-label="leguide.com (3 éléments)">leguide.com</a>
<a href="https://www.weezbe.com/blog/tag/livraison/" class="tag-cloud-link tag-link-103 tag-link-position-24" style="font-size: 15pt;" aria-label="livraison (5 éléments)">livraison</a>
<a href="https://www.weezbe.com/blog/tag/logistique/" class="tag-cloud-link tag-link-127 tag-link-position-25" style="font-size: 10.8pt;" aria-label="logistique (3 éléments)">logistique</a>
<a href="https://www.weezbe.com/blog/tag/marketing/" class="tag-cloud-link tag-link-163 tag-link-position-26" style="font-size: 13.133333333333pt;" aria-label="Marketing (4 éléments)">Marketing</a>
<a href="https://www.weezbe.com/blog/tag/module-export/" class="tag-cloud-link tag-link-102 tag-link-position-27" style="font-size: 8pt;" aria-label="module export (2 éléments)">module export</a>
<a href="https://www.weezbe.com/blog/tag/nouveautes/" class="tag-cloud-link tag-link-158 tag-link-position-28" style="font-size: 17.8pt;" aria-label="nouveautés (7 éléments)">nouveautés</a>
<a href="https://www.weezbe.com/blog/tag/optimiser/" class="tag-cloud-link tag-link-115 tag-link-position-29" style="font-size: 10.8pt;" aria-label="optimiser (3 éléments)">optimiser</a>
<a href="https://www.weezbe.com/blog/tag/paiement/" class="tag-cloud-link tag-link-59 tag-link-position-30" style="font-size: 10.8pt;" aria-label="paiement (3 éléments)">paiement</a>
<a href="https://www.weezbe.com/blog/tag/paiement-securise/" class="tag-cloud-link tag-link-61 tag-link-position-31" style="font-size: 13.133333333333pt;" aria-label="paiement sécurisé (4 éléments)">paiement sécurisé</a>
<a href="https://www.weezbe.com/blog/tag/performance/" class="tag-cloud-link tag-link-157 tag-link-position-32" style="font-size: 10.8pt;" aria-label="performance (3 éléments)">performance</a>
<a href="https://www.weezbe.com/blog/tag/plugin/" class="tag-cloud-link tag-link-139 tag-link-position-33" style="font-size: 13.133333333333pt;" aria-label="plugin (4 éléments)">plugin</a>
<a href="https://www.weezbe.com/blog/tag/reference/" class="tag-cloud-link tag-link-96 tag-link-position-34" style="font-size: 8pt;" aria-label="référence (2 éléments)">référence</a>
<a href="https://www.weezbe.com/blog/tag/referencement-naturel/" class="tag-cloud-link tag-link-63 tag-link-position-35" style="font-size: 10.8pt;" aria-label="référencement naturel (3 éléments)">référencement naturel</a>
<a href="https://www.weezbe.com/blog/tag/reseau-social/" class="tag-cloud-link tag-link-124 tag-link-position-36" style="font-size: 8pt;" aria-label="réseau social (2 éléments)">réseau social</a>
<a href="https://www.weezbe.com/blog/tag/reseaux-sociaux/" class="tag-cloud-link tag-link-106 tag-link-position-37" style="font-size: 8pt;" aria-label="réseaux sociaux (2 éléments)">réseaux sociaux</a>
<a href="https://www.weezbe.com/blog/tag/seo/" class="tag-cloud-link tag-link-66 tag-link-position-38" style="font-size: 13.133333333333pt;" aria-label="seo (4 éléments)">seo</a>
<a href="https://www.weezbe.com/blog/tag/shopping-com/" class="tag-cloud-link tag-link-67 tag-link-position-39" style="font-size: 10.8pt;" aria-label="shopping.com (3 éléments)">shopping.com</a>
<a href="https://www.weezbe.com/blog/tag/solution-e-commerce/" class="tag-cloud-link tag-link-69 tag-link-position-40" style="font-size: 13.133333333333pt;" aria-label="solution e-commerce (4 éléments)">solution e-commerce</a>
<a href="https://www.weezbe.com/blog/tag/taux-de-rebond/" class="tag-cloud-link tag-link-133 tag-link-position-41" style="font-size: 10.8pt;" aria-label="taux de rebond (3 éléments)">taux de rebond</a>
<a href="https://www.weezbe.com/blog/tag/taux-de-transformation/" class="tag-cloud-link tag-link-70 tag-link-position-42" style="font-size: 15pt;" aria-label="taux de transformation (5 éléments)">taux de transformation</a>
<a href="https://www.weezbe.com/blog/tag/version-weezbe/" class="tag-cloud-link tag-link-74 tag-link-position-43" style="font-size: 10.8pt;" aria-label="version weezbe (3 éléments)">version weezbe</a>
<a href="https://www.weezbe.com/blog/tag/weestore/" class="tag-cloud-link tag-link-88 tag-link-position-44" style="font-size: 15pt;" aria-label="weeStore (5 éléments)">weeStore</a>
<a href="https://www.weezbe.com/blog/tag/weezbe/" class="tag-cloud-link tag-link-89 tag-link-position-45" style="font-size: 8pt;" aria-label="weezbe (2 éléments)">weezbe</a></div>
</div>
				</div><!-- .entry-content -->
			</article><!-- #post-0 -->

		</div><!-- #content -->
	</div><!-- #primary -->


	</div><!-- #main -->

	<footer id="colophon" role="contentinfo">

		<div class="textwidget custom-html-widget"><div id="footer-infos">
	<h2>Déjà <script type="text/javascript">document.write(nb_store_created);</script> boutiques weezbe créées</h2>
	<p>Essai gratuit, <strong>illimité</strong> et sans engagement</p>
	<form action="#" id="sendMailFooterForm" method="post" class="create-store-form">
		<div>
			<input id="mail-footer" class="required validate-email" name="mail" placeholder="Votre adresse email" />
			<button type="submit" id="sendMailFooterLink" class="btn save">
				<span class="text">Créer ma boutique</span>
				<span class="icon hidden"><i class="fa fa-circle-o-notch fa-spin fa-lg fa-fw"></i></span>
			</button>
		</div>
		<input id="language" class="required" type="hidden" name="language" value="french">
		<input id="country" class="required" type="hidden" name="country" value="FRA">
		<input id="origin" name="origin" value="" type="hidden">
	</form>
	<div class="create-store-validation-message"></div>
</div></div>
		
<div id="supplementary" class="three">
		<div id="first" class="widget-area" role="complementary">
		<aside id="custom_html-4" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><h3>À propos</h3>
<p>
	Weezbe est un outil permettant de créer facilement et gratuitement une boutique en ligne professionnelle.<br />Adoptant un modèle économique à la performance, la solution e-commerce permet de lancer son activité sans coût de départ tout en profitant de fonctionnalités puissantes et étudiées pour la vente en ligne.<br />Depuis 2009, weezbe accompagne des centaines de marchands dans leur croissance en <strong>France</strong>, en <strong>Belgique</strong>, au <strong>Luxembourg</strong> et à <strong>l’international</strong>.
</p></div></aside>	</div><!-- #first .widget-area -->
	
		<div id="second" class="widget-area" role="complementary">
		<aside id="rss-3" class="widget widget_rss"><h3 class="widget-title">Actualités</h3><ul><li><a class='rsswidget' href='https://www.weezbe.com/blog/stripe-comment-lintegrer-a-votre-boutique-weezbe/'>Stripe : comment l’intégrer à votre boutique weezbe</a> <span class="rss-date">09-09-2018</span></li><li><a class='rsswidget' href='https://www.weezbe.com/blog/nouveau-theme-weezbe/'>Découvrez les thèmes graphiques pour weezbe</a> <span class="rss-date">30-06-2018</span></li><li><a class='rsswidget' href='https://www.weezbe.com/blog/reference-les-petites-chouettes/'>Les Petites Chouettes, mais qui sont-elles ?</a> <span class="rss-date">29-05-2018</span></li><li><a class='rsswidget' href='https://www.weezbe.com/blog/paiement-payzen/'>Nouvelle solution de paiement : PayZen</a> <span class="rss-date">16-04-2018</span></li></ul></aside>	</div><!-- #second .widget-area -->
	
		<div id="third" class="widget-area" role="complementary">
		<aside id="text-2" class="widget widget_text">			<div class="textwidget"><h3>En savoir plus</h3>
<ul>
<li><a href="/agence-web-e-commerce/nukium/" title="Agence e-commerce Nukium"><span class="icon nukium"></span>Notre agence Nukium</a></li>
<li><a href="/partenaires/"><span class="icon partners"></span>Nos partenaires &amp; solutions compatibles</a></li>
<li><a href="/contact/"><span class="icon contact"></span>Nous contacter</a></li>
<li><a href="/mentions-legales-e-commerce/"><span class="icon legal"></span>Mentions légales</a></li>
</ul>
<div id="social_links">
<h3>Nous suivre</h3>
<a class="social_media facebook" href="https://www.facebook.com/weezbe" rel="me" title="Suivez-nous sur Facebook">Facebook weezbe</a>
<a class="social_media twitter" href="https://twitter.com/weezbe" rel="me" title="Suivez-nous sur Twitter">Twitter weezbe</a>
</div></div>
		</aside>	</div><!-- #third .widget-area -->
	</div><!-- #supplementary -->			</footer><!-- #colophon -->
</div><!-- #page -->
</div><!-- #bgrd -->
	<div style="display:none">
	</div>
<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201843'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/www.weezbe.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Merci de confirmer que vous n\u2019\u00eates pas un robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.weezbe.com/wp-content/plugins/bwp-minify/min/?f=wp-content/plugins/contact-form-7/includes/js/scripts.js,wp-content/plugins/jetpack/_inc/build/widgets/milestone/milestone.min.js,wp-includes/js/wp-embed.min.js'></script>
<script type='text/javascript' src='https://stats.wp.com/e-201843.js' async='async' defer='defer'></script>
<script type='text/javascript'>
	_stq = window._stq || [];
	_stq.push([ 'view', {v:'ext',j:'1:6.4.2',blog:'100772978',post:'0',tz:'2',srv:'www.weezbe.com'} ]);
	_stq.push([ 'clickTrackerInit', '100772978', '0' ]);
</script>

<div class="cookies">
	<p>En poursuivant votre navigation, vous acceptez notre politique de confidentialité et notamment l'utilisation des cookies afin de réaliser des statistiques d'audiences.</p>
	<a href="/privacy-policy/">En savoir plus</a>
	<div class="btn_ok"><a id="jquery-cookies-btn" href="#">Compris !</a></div>
</div>

<!--Start of Zendesk Chat Script-->
</body>
</html>